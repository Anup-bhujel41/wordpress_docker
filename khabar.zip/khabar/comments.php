<div class="d-flex title-border ">
    <div class="title-design position-relative">
        <div class="">
            <a href="">
                <h4 class="fw-bold">प्रतिक्रिया दिनुहोस</h4>
            </a>
        </div>
    </div>
</div>

<div class="clearfix pt-3">
    <div class="comment">
        <div class="fb-comments" data-href="<?php the_permalink();?>" data-width="100%" data-numposts="10"
            data-colorscheme="light"></div>
    </div>
</div>