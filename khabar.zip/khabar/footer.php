</div>
</div>

<div class="footer-section ">
    <div class="container">
        <div class="row pt-2 pb-2">

            <!-- <div class="col-md-12">
                <ul class="nav justify-content-center img-social-link">
                    <li class="nav-item">
                        <a title="facebook" href=""><i class="bi bi-facebook"></i></a>
                    </li>
                    <li class="nav-item">
                        <a title="instagram" href=""><i class="bi bi-instagram p-2"></i></a>
                    </li>
                    <li class="nav-item">
                        <a title="twitter" href=""><i class="bi bi-twitter"></i></a>
                    </li>
                    <li class="nav-item">
                        <a title="youtube" href=""><i class="bi bi-youtube"></i></a>
                    </li>
                </ul>
            </div> -->

            <hr class="w-100" style="background: #ddd;">

            <div class="col-md-6">
                <ul class="nav flex-column footer-section-list">
                    <li class="nav-item">
                        <a class="nav-link text-light"><b><i class=""></i>REG NO : 295/073-74</b></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light"><b><i class=""></i>Editorial director : </b> purna prashad
                            neupane</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light"><b><i class=""></i>Sb jero : </b>Editor</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light"><b><i class=""></i> Managing Director : </b> Rabin Shrestha</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link text-light"><b><i class=""></i>Address : </b>
                            Madhya marga, Kathmandu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light"><b><i class=""></i>Phone : </b>
                            +977-01-4795000
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light"><b><i class=""></i>E-mail : </b>
                            mail@freedomkhabar59.com</a>
                    </li>
                </ul>
            </div>

            <div class="col-md-6">
                <h4 class="text-light">Quick navigation</h4>

                <div class="row">
                    <div class="col">
                        <ul class="nav flex-column footer-section-list">
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=11">Economy </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=18">Banking</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=1">World</a>
                            </li>
                        </ul>
                    </div>

                    <div class="col">
                        <ul class="nav flex-column footer-section-list">
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=132">Share Bazaar</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=85">Corporate</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=15">Country</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=169">Education</a>
                            </li>
                        </ul>
                    </div>

                    <div class="col">
                        <ul class="nav flex-column footer-section-list">
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=68">Politics</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=4">Society</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=21">Development</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=649">Lifestyle</a>
                            </li>
                        </ul>
                    </div>

                    <div class="col">
                        <ul class="nav flex-column footer-section-list">
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=39">Idea</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=23">Interview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=17198">Blog</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="/?cat=199">Auto</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid" style="background:#18243a">
    <div class="container">
        <div class="row pt-4 pb-2">
            <div class="col-sm-3 social d-flex text-center">
                <a class="btn" target="_blank" href="">
                    <i class="fa fa-facebook"></i>
                </a>
                <a class="btn" target="_blank" href="">
                    <i class="fa fa-twitter"></i>
                </a>
                <a class="btn" target="_blank" href="">
                    <i class="fa fa-youtube"></i>
                </a>
                <a class="btn" target="_blank" href="">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>

            </div>

            <div class="col-sm-6 text-light align-self-center">
                <nav class="navbar navbar-expand col footer-nav p-0">
                    <div class="collapse navbar-collapse" id="main-menu">
                        <ul class="navbar-nav mr-auto w-100 justify-content-center">
                            <li class="nav-item mr-1">
                                <a class="nav-link" href="">About Us</a>
                            </li>
                            <li class="nav-item mr-1">
                                <a class="nav-link" href="">
                                    Advertise</a>
                            </li>
                            <li class="nav-item mr-1">
                                <a class="nav-link" href="">Contact</a>
                            </li>
                            <li class="nav-item mr-1">
                                <a class="nav-link" href="/preeti-to-unicode/">Preeti to unicode</a>
                            </li>
                            <li class="nav-item mr-1">
                                <a class="nav-link" href="/media-kit/">Media Kit</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>

            <div class="col-sm-3 text-light align-self-center text-right">
                Contact Us:
                <a href="mailto:info@newsofnepal.com" style="color:#fff;">
                    <email> freedomkhabar59@gmail.com.com</email>
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid text-light" style="background-color:#e2113b;">
    <div class="container pb-4 pt-4">
        <div class="row ">
            <div class="col-md-8">
                © 2002 -
                <?php echo date('Y');?> BI Publications Pvt. Ltd. all Rights
                Reserved. फ्रिडम खबर प्रा.लि..
            </div>

            <div class="col-md-4 col-12 text-right">
                <a href="" class="text-light">
                    Designed & Developed by : Appharu.com
                </a>
            </div>
        </div>
    </div>
</div>

<div class="scroll-top-wrapper ">
    <span class="scroll-top-inner">
    </span>
</div>

<?php wp_footer();?>
</body>

</html>